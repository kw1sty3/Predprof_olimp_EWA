using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public static class Object
{
    public static GameObject ChooseObject;
}
